<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('magasins', function (Blueprint $table) {
            $table->id();

            $table->string('libelle')->nullable();
            $table->string('responsable')->nullable();
            $table->mediumText('description')->nullable();
            $table->text('adresse')->nullable();
    $table->string('telephone')->nullable();
    
    $table->tinyInteger('type')->default(1); // 1=entrepôt, 2=boutique
         

            $table->integer('etat')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('magasins');
    }
};
